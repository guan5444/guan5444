<label class="switch">
    <input type="checkbox" {{ $attributes }}>
    <div class="slider round"></div>
</label>
