<span {{ $attributes }}>{{ \App\Utils::config(\App\Enums\ConfigKey::AppName) }}</span>
