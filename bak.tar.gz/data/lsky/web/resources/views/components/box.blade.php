<div class="rounded w-full overflow-hidden shadow-custom">
    <div class="px-4 py-3 bg-slate-50 text-gray-800 text-md truncate">{{ $title }}</div>
    <div class="bg-white w-full">
        {{ $content }}
    </div>
</div>
