@section('title', '上传图片')

<x-app-layout>
    <div class="my-6 md:my-9">
        <x-upload/>
    </div>
</x-app-layout>
