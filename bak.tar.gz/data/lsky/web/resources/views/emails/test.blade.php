<p>
    您好，这是一封来自 {{ \App\Utils::config(\App\Enums\ConfigKey::AppName) }} 的测试邮件，当您看到这封邮件后，说明邮件配置正确。如果不是您本人操作，请忽略。
</p>
