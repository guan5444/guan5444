<p class="bg-blue-500 p-2 mb-2 rounded text-sm text-white">
    <i class="fas fa-exclamation-circle"></i> 一个策略可以关联多个角色组，一个角色组也可以关联多个策略，注意，如果某个组未设置储存策略，那么该角色组下的用户将无法上传图片。
</p>
<?php /**PATH /var/www/html/resources/views/admin/strategy/tips.blade.php ENDPATH**/ ?>