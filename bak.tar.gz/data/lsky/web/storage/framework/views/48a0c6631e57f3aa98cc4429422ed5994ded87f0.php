<div class="rounded w-full overflow-hidden shadow-custom">
    <div class="px-4 py-3 bg-slate-50 text-gray-800 text-md truncate"><?php echo e($title); ?></div>
    <div class="bg-white w-full">
        <?php echo e($content); ?>

    </div>
</div>
<?php /**PATH /var/www/html/resources/views/components/box.blade.php ENDPATH**/ ?>