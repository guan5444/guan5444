<fieldset>
    <legend class="text-base font-medium text-gray-900"><?php echo e($title); ?></legend>
    <?php if(isset($faq)): ?>
        <p class="text-sm text-gray-500"><?php echo $faq; ?></p>
    <?php endif; ?>
    <div class="flex flex-wrap mt-4">
        <?php echo e($slot); ?>

    </div>
</fieldset>
<?php /**PATH /var/www/html/resources/views/components/fieldset.blade.php ENDPATH**/ ?>