<pre <?php echo e($attributes->merge(['class' => 'my-2 bg-white rounded-md p-4 text-sm bg-gray-500 text-white overflow-x-auto'])); ?>>
<?php echo e($slot ?? ''); ?>

</pre>
<?php /**PATH /var/www/html/resources/views/components/code.blade.php ENDPATH**/ ?>