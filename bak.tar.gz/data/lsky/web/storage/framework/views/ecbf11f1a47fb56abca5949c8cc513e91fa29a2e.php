<div class="flex items-center mr-4">
    <input type="radio" <?php echo e($attributes->merge(['id' => $id, 'name' => $name, 'class' => 'focus:ring-indigo-500 h-4 w-4 text-indigo-600 border-gray-300', 'value' => $value ?? 0])); ?>>
    <label for="<?php echo e($id); ?>" class="ml-3 block text-sm font-medium text-gray-700"><?php echo e($slot); ?></label>
</div>
<?php /**PATH /var/www/html/resources/views/components/fieldset-radio.blade.php ENDPATH**/ ?>