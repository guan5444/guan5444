<label class="switch">
    <input type="checkbox" <?php echo e($attributes); ?>>
    <div class="slider round"></div>
</label>
<?php /**PATH /var/www/html/resources/views/components/switch.blade.php ENDPATH**/ ?>