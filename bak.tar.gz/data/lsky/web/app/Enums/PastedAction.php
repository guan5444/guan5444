<?php

namespace App\Enums;

final class PastedAction
{
    const Upload  = 2; // 直接上传
    const Waiting = 1; // 等待上传
}
