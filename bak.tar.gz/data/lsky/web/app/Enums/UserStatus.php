<?php

namespace App\Enums;

final class UserStatus
{
    /** @var int 正常 */
    const Normal = 1;

    /** @var int 冻结 */
    const Frozen = 0;
}
