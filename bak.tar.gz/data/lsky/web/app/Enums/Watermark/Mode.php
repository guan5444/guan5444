<?php

namespace App\Enums\Watermark;

final class Mode
{
    const Overlay = 1; // 覆盖原图
    const Dynamic = 2; // 动态生成
}
