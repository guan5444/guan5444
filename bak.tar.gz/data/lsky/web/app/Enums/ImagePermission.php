<?php

namespace App\Enums;

final class ImagePermission
{
    const Public  = 1; // 公开
    const Private = 0; // 私有
}
