docker compose down
docker rm -f xiaoya
docker pull xiaoyaliu/alist:latest
if [ -d /data/xiaoya/data/mytoken.txt ]; then
    rm -rf /data/xiaoya/mytoken.txt
fi
mkdir -p /data/xiaoya/data
touch /data/xiaoya/data/mytoken.txt
touch /data/xiaoya/data/pikpak.txt
touch /data/xiaoya/data/guestpass.txt
docker compose up -d
